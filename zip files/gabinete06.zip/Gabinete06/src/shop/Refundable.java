// package declaration
package shop;

// interface definition
public interface Refundable {
	void refund();
}
