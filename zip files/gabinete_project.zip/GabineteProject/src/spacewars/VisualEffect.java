package spacewars;

public interface VisualEffect {
	int FRAME_SPEED = 6;

	void applyEffect();
	void animate();
}
